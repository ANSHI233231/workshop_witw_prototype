# Starter Prototype

Clickable HTML prototype of Walk Into The Wild (WITW): **Admin Console**, **website** (Portal), **Shared Safari**, and **Packages** with the **Partner portal**, plus **Wishlist, Profiles and Direct Chat**. Same boards as the design canvas "Starter Prototype – Repo Copy" (version 33). Works offline in any modern browser; no install or server.

## How to open

| Option | Open this | What you get |
|---|---|---|
| Single file | `Starter-Prototype.html` | Every screen in one file (photos included), starting at Admin-Sign-In |
| Standalone screens | `screens/<Screen>.html` | One screen per file; links and the board list move between screen files |

- Open a board directly by adding its name after `#`, e.g. `Starter-Prototype.html#P5-Parks-list` or `#PP6-Gallery.mobile`.
- Keep `screens/` together: its stylesheets, `support.js` and `img/` must stay beside the screen files.
- Only the Roboto font loads from the internet; offline, the system font is used.

## Mobile and responsive

| Screen width | What you see |
|---|---|
| Phone (under 700 px) | `Starter-Prototype.html` opens the **mobile** board of every screen automatically |
| Tablet and small laptop (700–900 px) | Desktop boards adapt: header menu stacks, tabs scroll, wide tables scroll inside their card |
| Desktop | Desktop boards; use **Desktop / Mobile** in the prototype bar to switch |

## Prototype bar (top of every screen)

| Control | Use |
|---|---|
| Console / Portal / Partner portal | Switch app |
| Board list | Jump to any screen |
| Desktop / Mobile | Switch between 1366 px and a 390 px phone frame |
| Reset data | Clear everything added or changed and return to the sample data |
| View as · Package · Gallery · Park · Partner · Profile · Accounts | Choose the viewer and what a screen shows (varies by board) |

## Screens (67 boards × desktop + mobile = 134 screens)

| Group | Boards |
|---|---|
| Console (16) | Admin-Sign-In, Forgot-Password, Dashboard, Users, Roles, Notifications, Notification-Templates, Delivery-Log, Audit-Log, System-Logs, Error-Logs, Background-Jobs, Language-Master, Language-Translation, Tech-Documentation, Not-Found |
| Portal (5) | Web-Sign-In, Web-Sign-Up, Web-Forgot-Password, Web-Notifications, Web-Not-Found |
| Shared Safari · Website (9) | W1 Shared Safaris list · W2 Safari card · W3 Shared Safari view · W4 Who joined · W5 Organise a Safari / Edit · W6 Change status · W7 Delete and Leave · W8 Flag a comment · W9 My Shared Safaris |
| Shared Safari · Console (7) | C1 Shared Safaris list · C2 Joined / Left list · C3 Shared Safari detail · C4 Flagged Comments · C5 Parks list (Add park) · C6 Park detail (Edit park) · C7 Flag Reasons |
| Packages · Website (6) | P1 Packages list · P2 Package page, Request a quote · P3 My Quote Requests · P4 Become a Partner · P5 Plan Safari (Parks list) · P6 Park page |
| Packages · Partner portal (10) | PP1 Sign In · PP2 Partner request status · PP3 Dashboard · PP4 Packages · PP5 Add / Edit package · PP6 Gallery · PP7 Add / Edit gallery · PP8 Quote Requests · PP9 Business Profile · PP10 Notifications (from the bell: Show all notifications) |
| Packages · Console (9) | PC1 Partner Requests · PC2 Partners · PC3 Package Approvals · PC4 Packages · PC5 Package preview / edit · PC6 Package Delete Reasons · PC7 Gallery Approvals · PC8 Galleries · PC9 Quote Requests |
| Profiles · Wishlist · Chat · Website (5) | U1 Wishlist · U2 Partner Profile · U3 User Profile · U4 Edit Profile · U5 Messages |

Mobile files add `.mobile`, e.g. `screens/P6-Park-page.mobile.html`.

## Flows to try

| Flow | Where |
|---|---|
| Build a package, send, approve (Popular is cleared) | PP5 → PP4 → PC3 / PC5 → P1 |
| Price checks: total below price per person, discount price too low | PP5 › Basic › Save |
| Fewer days removes itinerary days after a confirmation | PP5 › Wildlife Marathon › Days |
| View an old (Replaced) version, read-only | PP5 › Wild Kanha Special › Versions › View |
| Super Admin edits only name, prices, messages, overview, getting there | PC5 › Edit |
| Delete a draft: "This draft will be discarded." | PP4 / PP5 |
| Approved gallery with waiting changes: "Approved (live)" and "Changes to approved gallery" | PP6 › Approved / Waiting → PC7 |
| Draft of an approved gallery (In Draft tab) | PP7 › Corbett Elephant Camp › Move back to draft |
| Send a gallery: notification in the console bell | PP6 › In Draft › Send → PC7 bell |
| Add / edit a park: description, location, feature image (JPG, JPEG or PNG, up to 250 KB) | C5 / C6 → P5 / P6 |
| Park page: Overview (map), Packages, Shared Safaris | P6 |
| Plan Safari in the website top bar opens the Parks list | Any website screen → P5 |
| Partner notifications: sidebar Notifications, or bell › Show all notifications | PP3 → PP10 |
| Demo sign-in: pick a card (Partner, Partner 2, Pending, Rejected, Inactive, No request), then Sign in | PP1 |
| Console Partner card opens the Partner portal sign-in | Admin-Sign-In → PP1 |
| Save with ♥: packages and shared safaris; a guest is sent to Sign in and comes back | P1 / P2 / P6 / W3 → U1 |
| Wishlist: Packages and Shared Safaris tabs, 6 at a time with Load More | Account menu › Wishlist (U1) |
| Hidden package: drops out; comes back only if its price per person is unchanged | PP4 / PC4 hide and show → U1 |
| Partner Profile: Packages / Parks tiles and tabs; inactive or unknown → home page | P2 "Operated by", PP9 › View public page → U2 |
| User Profile: guest sees only the header and Sign in; own profile shows Edit Profile | Any user name → U3 |
| Edit Profile: each tab saved on its own; photo replaces initials everywhere | Account menu › My Profile (U4) |
| Existing user without date of birth or gender can still save (to confirm) | U4 › View as Amit |
| Message another user: first message creates the conversation | U3 › Message → U5 |
| Messages: unread counts, mark read on open, 1,000-character limit | Account menu › Messages (U5) |
| Live chat: send as one user, switch View as to the other | U5 |
| Deactivated account: "This account is deactivated. Your message can't be sent." | U5 › Accounts: Sanjay, View as Riya |
| Message notification "Name sent you a message." opens the conversation | Bell / Web-Notifications → U5 |

## Notes

| Topic | Detail |
|---|---|
| Sizes | Desktop 1366 × 768 · Mobile 390 × 844 |
| Design | WITW Design System (primary #09422D), website styled like walkintothewild.in |
| Data | Sample data, kept in this browser until Reset data |
| Map | Park page shows a static Leaflet-style map with a pin (no live map offline) |
| Plan Safari | Opens the Parks list (P5); greyed out on Sign In, Sign Up and Forgot Password |
| To confirm | Items marked "to confirm" in the review (e.g. price checks, description 1,000 characters, wishlist price per person, profile and chat error messages, 1,000-character message limit) are assumptions, not signed-off rules |
| Demo only | Sign-in cards, demo password "password123", the pre-loaded gallery state, sample profiles (Riya, Ananya, Neha; Amit with no details), sample wishlist items, sample conversations and *.example social links are prototype conveniences, not workflow rules |
